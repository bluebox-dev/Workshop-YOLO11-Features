# Coin-Segment > 2025-11-04 12:48am
https://universe.roboflow.com/workshop-l1gag/coin-segment-adcnq

Provided by a Roboflow user
License: CC BY 4.0

